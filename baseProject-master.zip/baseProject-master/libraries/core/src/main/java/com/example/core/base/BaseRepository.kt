package com.example.core.base

open class BaseRepository