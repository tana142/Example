package com.example.core.model.network

open class BaseResponse
