package com.example.core.network

interface AuthApiInterface