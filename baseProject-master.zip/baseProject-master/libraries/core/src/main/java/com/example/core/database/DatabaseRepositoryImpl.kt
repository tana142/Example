package com.example.core.database

import javax.inject.Inject

class DatabaseRepositoryImpl @Inject constructor() : DatabaseRepository