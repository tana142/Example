package com.example.core.database

interface DatabaseRepository