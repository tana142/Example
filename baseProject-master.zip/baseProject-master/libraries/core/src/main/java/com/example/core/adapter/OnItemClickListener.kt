package com.example.core.adapter

interface OnItemClickListener {
    fun onItemClick(position: Int)
}