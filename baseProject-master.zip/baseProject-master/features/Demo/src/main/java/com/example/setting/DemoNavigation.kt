package com.example.setting

import com.example.core.navigationComponent.BaseNavigator

interface DemoNavigation : BaseNavigator