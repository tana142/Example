package com.example.setting.model

class Ahihi constructor() {
    var a = 5
}